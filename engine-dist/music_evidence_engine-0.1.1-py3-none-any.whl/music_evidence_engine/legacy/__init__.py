# -*- coding: utf-8 -*-
# 迁移保护层：analyze.py 保持 dsh-soundcheck v0.9.10 原样。
